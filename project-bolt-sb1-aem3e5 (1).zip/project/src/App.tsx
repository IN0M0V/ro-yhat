import React, { useState } from 'react';
import { PatientRegistration } from './components/PatientRegistration';
import { PrescriptionForm } from './components/PrescriptionForm';
import { PatientSearch } from './components/PatientSearch';
import { Patient, Prescription } from './types';

function App() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);

  const handleAddPatient = (patient: Patient) => {
    setPatients([...patients, patient]);
  };

  const handleAddPrescription = (prescription: Prescription) => {
    setPrescriptions([...prescriptions, prescription]);
    setSelectedPatient(null);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Shifoxona boshqaruv tizimi</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <PatientRegistration onAddPatient={handleAddPatient} />
          
          <PatientSearch 
            patients={patients}
            onSelectPatient={setSelectedPatient}
          />
          
          {selectedPatient && (
            <PrescriptionForm
              patient={selectedPatient}
              onAddPrescription={handleAddPrescription}
            />
          )}
        </div>

        {prescriptions.length > 0 && (
          <div className="mt-8">
            <h2 className="text-2xl font-semibold mb-4">So'nggi retseptlar</h2>
            <div className="space-y-4">
              {prescriptions.map((prescription) => {
                const patient = patients.find(p => p.id === prescription.patientId);
                return (
                  <div key={prescription.id} className="bg-white p-4 rounded-lg shadow">
                    <div className="mb-2">
                      <span className="font-medium">Bemor: </span>
                      {patient?.fullName}
                    </div>
                    <div className="mb-2">
                      <span className="font-medium">Tashxis: </span>
                      {prescription.diagnosis}
                    </div>
                    <div>
                      <span className="font-medium">Dorilar:</span>
                      <ul className="mt-2 space-y-2">
                        {prescription.medications.map((med, index) => (
                          <li key={index} className="ml-4">
                            • {med.name} - {med.dosage} ({med.frequency}, {med.duration})
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;