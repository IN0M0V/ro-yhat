import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { Patient } from '../types';

interface Props {
  patients: Patient[];
  onSelectPatient: (patient: Patient) => void;
}

export function PatientSearch({ patients, onSelectPatient }: Props) {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredPatients = patients.filter(
    (patient) =>
      patient.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.phone.includes(searchTerm)
  );

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center gap-2 mb-6">
        <Search className="h-6 w-6 text-gray-600" />
        <h2 className="text-xl font-semibold">Bemorlarni qidirish</h2>
      </div>

      <div className="mb-4">
        <input
          type="text"
          placeholder="Ism yoki telefon raqami bo'yicha qidiring..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
      </div>

      <div className="space-y-2">
        {filteredPatients.map((patient) => (
          <div
            key={patient.id}
            onClick={() => onSelectPatient(patient)}
            className="p-3 border rounded-md hover:bg-gray-50 cursor-pointer"
          >
            <p className="font-medium">{patient.fullName}</p>
            <p className="text-sm text-gray-600">{patient.phone}</p>
          </div>
        ))}
      </div>
    </div>
  );
}