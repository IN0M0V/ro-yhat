import React, { useState } from 'react';
import { Stethoscope } from 'lucide-react';
import { Prescription, Patient } from '../types';

interface Props {
  patient: Patient;
  onAddPrescription: (prescription: Prescription) => void;
}

export function PrescriptionForm({ patient, onAddPrescription }: Props) {
  const [prescription, setPrescription] = useState({
    diagnosis: '',
    medications: [{ name: '', dosage: '', frequency: '', duration: '' }],
  });

  const handleAddMedication = () => {
    setPrescription({
      ...prescription,
      medications: [...prescription.medications, { name: '', dosage: '', frequency: '', duration: '' }],
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newPrescription: Prescription = {
      id: Date.now().toString(),
      patientId: patient.id,
      diagnosis: prescription.diagnosis,
      medications: prescription.medications,
      date: new Date().toISOString(),
    };
    onAddPrescription(newPrescription);
    setPrescription({ diagnosis: '', medications: [{ name: '', dosage: '', frequency: '', duration: '' }] });
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center gap-2 mb-6">
        <Stethoscope className="h-6 w-6 text-green-600" />
        <h2 className="text-xl font-semibold">Retsept yozish</h2>
      </div>

      <div className="mb-4 p-3 bg-blue-50 rounded-md">
        <p className="font-medium">Bemor: {patient.fullName}</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Tashxis</label>
          <textarea
            value={prescription.diagnosis}
            onChange={(e) => setPrescription({ ...prescription, diagnosis: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
            required
            rows={3}
          />
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium">Dorilar</h3>
            <button
              type="button"
              onClick={handleAddMedication}
              className="text-sm text-green-600 hover:text-green-700"
            >
              + Dori qo'shish
            </button>
          </div>

          {prescription.medications.map((med, index) => (
            <div key={index} className="p-4 border rounded-md space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700">Dori nomi</label>
                <input
                  type="text"
                  value={med.name}
                  onChange={(e) => {
                    const newMeds = [...prescription.medications];
                    newMeds[index].name = e.target.value;
                    setPrescription({ ...prescription, medications: newMeds });
                  }}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Miqdori</label>
                  <input
                    type="text"
                    value={med.dosage}
                    onChange={(e) => {
                      const newMeds = [...prescription.medications];
                      newMeds[index].dosage = e.target.value;
                      setPrescription({ ...prescription, medications: newMeds });
                    }}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Qabul qilish</label>
                  <input
                    type="text"
                    value={med.frequency}
                    onChange={(e) => {
                      const newMeds = [...prescription.medications];
                      newMeds[index].frequency = e.target.value;
                      setPrescription({ ...prescription, medications: newMeds });
                    }}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Davomiyligi</label>
                  <input
                    type="text"
                    value={med.duration}
                    onChange={(e) => {
                      const newMeds = [...prescription.medications];
                      newMeds[index].duration = e.target.value;
                      setPrescription({ ...prescription, medications: newMeds });
                    }}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                    required
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        <button
          type="submit"
          className="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
        >
          Retseptni saqlash
        </button>
      </form>
    </div>
  );
}