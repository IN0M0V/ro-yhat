export interface Patient {
  id: string;
  fullName: string;
  dateOfBirth: string;
  phone: string;
  address: string;
  registrationDate: string;
}

export interface Prescription {
  id: string;
  patientId: string;
  diagnosis: string;
  medications: Medication[];
  date: string;
}

export interface Medication {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
}